/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import dto.Categoria;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Optional;
import java.util.OptionalInt;

/**
 *
 * @author ciclost
 */
public class CategoriaDAO extends TablaDAO<Categoria>{
    
    public CategoriaDAO(){
        this.tabla = "CATEGORIA";
    }

    @Override
    public int actualizar(Categoria objeto) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int anyadir(Categoria c) throws SQLException {
        String sentenciaSQL = "INSERT INTO " + tabla + " VALUES(?)";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setString(1, c.getNombre());
        return prepared.executeUpdate();
    }

    @Override
    public Categoria eliminar(Categoria c) throws SQLException {
        String sentenciaSQL = "DELETE FROM " + tabla + " WHERE nombre=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setString(1, c.getNombre());
        prepared.executeUpdate();
        return c;
    }

    public boolean existe(String nombre) throws SQLException{
        return this.getNombreDe(nombre).isPresent();
    }
    
    @Override
    public boolean existe(Categoria c) throws SQLException {
        return existe(c.getNombre());
    }
    
    

    @Override
    public ArrayList<Categoria> getAll() throws SQLException {
        ArrayList<Categoria> listaCategorias = new ArrayList<>();
        String sentenciaSQL = "SELECT * FROM " + tabla + " ORDER BY nombre";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            String nombre = resultSet.getString("nombre");
            listaCategorias.add(new Categoria(nombre));
        }
        
        return listaCategorias;
    }

    @Override
    public Categoria getByCodigo(int codigo) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    public Optional<String> getNombreDe(String nombre) throws SQLException {
        String sentenciaSQL = "SELECT nombre FROM " + tabla + " WHERE nombre=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setString(1, nombre);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            return Optional.of(resultSet.getString("nombre"));
        }
        
        return Optional.empty();
    }
    
    public Categoria getByNombre(String nombre) throws SQLException {
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE nombre=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setString(1, nombre);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            String nom = resultSet.getString("nombre");
            return new Categoria(nom);
        }

        return null;
    }
    
}
