/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import dto.Tarjeta;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author ciclost
 */
public class TarjetaDAO extends TablaDAO<Tarjeta>{

    public TarjetaDAO() {
        this.tabla = "TARJETA";
    }

    @Override
    public int actualizar(Tarjeta objeto) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int anyadir(Tarjeta t) throws SQLException {
        String sentenciaSQL = "INSERT INTO " + tabla + " VALUES(?)";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, t.getCodigo());
        return prepared.executeUpdate();
    }

    @Override
    public Tarjeta eliminar(Tarjeta t) throws SQLException {
        if (t == null) {
            return null;
        } else {
            return eliminar(t.getCodigo()) != null ? t : null;
        }
    }

    @Override
    public boolean existe(Tarjeta t) throws SQLException {
        return existe(t.getCodigo());
    }

    @Override
    public ArrayList<Tarjeta> getAll() throws SQLException {
        ArrayList<Tarjeta> lista = new ArrayList<>();
        String sentenciaSQL = "SELECT * FROM " + tabla + " ORDER BY codigo";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            int cod = resultSet.getInt("codigo");
            lista.add(new Tarjeta(cod));
        }
        return lista;
    }

    @Override
    public Tarjeta getByCodigo(int codigo) throws SQLException {
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE codigo=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, codigo);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            int cod = resultSet.getInt("codigo");
            return new Tarjeta(cod);
        }
        return null;
    }
    
}
