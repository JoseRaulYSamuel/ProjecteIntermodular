/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dto;

import java.util.ArrayList;
import java.util.Objects;

/**
 *
 * @author s4mu3
 */
public class Articulo {
    private int codigo;
    private String nombre;
    private double pvp;
    private String descripcion;
    private String foto;
    private int cantidad;
    private ArrayList<Categoria> categorias;
    private Marca marca;
    private Usuario creador;
    private Usuario modificador;
    private TipoArticulo tipo;

    public Articulo(int codigo, String nombre, double pvp, String descripcion, String foto, int cantidad, ArrayList<Categoria> categorias, Marca marca, Usuario creador, Usuario modificador, TipoArticulo tipo) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.pvp = pvp;
        this.descripcion = descripcion;
        this.foto = foto;
        this.cantidad = cantidad;
        this.categorias = categorias;
        this.marca = marca;
        this.creador = creador;
        this.modificador = modificador;
        this.tipo = tipo;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPvp() {
        return pvp;
    }

    public void setPvp(double pvp) {
        this.pvp = pvp;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public ArrayList<Categoria> getCategorias() {
        return categorias;
    }

    public void setCategorias(ArrayList<Categoria> categorias) {
        this.categorias = categorias;
    }

    public Marca getMarca() {
        return marca;
    }

    public void setMarca(Marca marca) {
        this.marca = marca;
    }

    public Usuario getCreador() {
        return creador;
    }

    public void setCreador(Usuario creador) {
        this.creador = creador;
    }

    public Usuario getModificador() {
        return modificador;
    }

    public void setModificador(Usuario modificador) {
        this.modificador = modificador;
    }

    public TipoArticulo getTipo() {
        return tipo;
    }

    public void setTipo(TipoArticulo tipo) {
        this.tipo = tipo;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 89 * hash + this.codigo;
        hash = 89 * hash + Objects.hashCode(this.nombre);
        hash = 89 * hash + (int) (Double.doubleToLongBits(this.pvp) ^ (Double.doubleToLongBits(this.pvp) >>> 32));
        hash = 89 * hash + Objects.hashCode(this.descripcion);
        hash = 89 * hash + Objects.hashCode(this.foto);
        hash = 89 * hash + this.cantidad;
        hash = 89 * hash + Objects.hashCode(this.categorias);
        hash = 89 * hash + Objects.hashCode(this.marca);
        hash = 89 * hash + Objects.hashCode(this.creador);
        hash = 89 * hash + Objects.hashCode(this.modificador);
        hash = 89 * hash + Objects.hashCode(this.tipo);
        return hash;
    }

    

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Articulo other = (Articulo) obj;
        if (this.codigo != other.codigo) {
            return false;
        }
        if (this.pvp != other.pvp) {
            return false;
        }
        if (this.cantidad != other.cantidad) {
            return false;
        }
        if (!Objects.equals(this.nombre, other.nombre)) {
            return false;
        }
        if (!Objects.equals(this.descripcion, other.descripcion)) {
            return false;
        }
        if (!Objects.equals(this.foto, other.foto)) {
            return false;
        }
        if (!Objects.equals(this.categorias, other.categorias)) {
            return false;
        }
        if (!Objects.equals(this.marca, other.marca)) {
            return false;
        }
        if (!Objects.equals(this.creador, other.creador)) {
            return false;
        }
        if (!Objects.equals(this.modificador, other.modificador)) {
            return false;
        }
        return this.tipo == other.tipo;
    }
    
    
}
