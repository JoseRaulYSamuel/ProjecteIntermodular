/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import dto.Articulo;
import dto.Categoria;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author ciclost
 */
public class prueba {
    public static void main(String[] args) throws SQLException {
        ArticuloDAO prueba = new ArticuloDAO();
        Categoria cat1 = new Categoria("prueba2");
        ArrayList<Categoria> categoria = new ArrayList<>();
        categoria.add(cat1);
        CategoriaDAO categoria1 = new CategoriaDAO();
        categoria1.anyadir(cat1);
        Articulo articulo = new Articulo(2222, "hola", 3, "nada", null, 1, categoria, null, null, null, null);
        prueba.anyadir(articulo);
        
        System.out.println(prueba.getAll());
    }
}
