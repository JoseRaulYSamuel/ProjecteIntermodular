/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import dto.Cesta;
import dto.Tarjeta;
import dto.TipoUsuario;
import dto.Usuario;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;

/**
 *
 * @author ciclost
 */
public class UsuarioDAO extends TablaDAO<Usuario>{

    public UsuarioDAO() {
        this.tabla = "USUARIO";
    }

    @Override
    public int actualizar(Usuario u) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int anyadir(Usuario u) throws SQLException {
        String sentenciaSQL = "INSERT INTO " + tabla + " VALUES(?,?,?,?,?,?,?,?,?)";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, u.getCodigo());
        prepared.setString(2, u.getNombreCompleto());
        LocalDate fechaNac = u.getFechNac();
        if (fechaNac == null) {
            prepared.setNull(3, java.sql.Types.DATE);
        } else {
            prepared.setDate(3, Date.valueOf(fechaNac));
        }
        prepared.setString(4, u.getContraseña());
        prepared.setString(5, u.getEmail());
        if (u.getFoto() == null) {
            prepared.setNull(6, java.sql.Types.VARCHAR);
        } else {
            prepared.setString(6, u.getFoto());
        }
        prepared.setInt(7, u.getTelefono());
        prepared.setString(8, String.valueOf(u.getTipo()));
        LocalDateTime ultimaConexion = u.getUltConexion();
        if (ultimaConexion == null) {
            prepared.setNull(9, java.sql.Types.TIMESTAMP);
        } else {
            prepared.setTimestamp(9, Timestamp.valueOf(ultimaConexion));
        }
        int resultado = prepared.executeUpdate();
        anyadirTarjeta(u);
        return resultado;
    }

    @Override
    public Usuario eliminar(Usuario u) throws SQLException {
        if (u == null) {
            return null;
        } else {
            return eliminar(u.getCodigo()) != null ? u : null;
        }
    }

    @Override
    public boolean existe(Usuario u) throws SQLException {
        return existe(u.getCodigo());
    }
    
    public ArrayList<Tarjeta> getTarjetas(int codigo) throws SQLException{
        TarjetaDAO tarjetaDAO = new TarjetaDAO();
        ArrayList<Tarjeta> tarjetas = new ArrayList<>();
        String sentenciaSQL = "SELECT tarjeta FROM TARJETAS_VINCULADAS WHERE CLIENTE = ?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, codigo);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            Tarjeta tarjeta = tarjetaDAO.getByCodigo(resultSet.getInt("tarjeta"));
            tarjetas.add(tarjeta);
        }
        return tarjetas;
    }
    
    private void anyadirTarjeta(Usuario u) throws SQLException {
        for (Tarjeta t : u.getTarjeta()) {
            String sentenciaSQL = "INSERT INTO TARJETAS_VINCULADAS VALUES(?, ?)";
            PreparedStatement prepared = getPrepared(sentenciaSQL);
            prepared.setInt(1, u.getCodigo());
            prepared.setInt(2, t.getCodigo());
            prepared.executeUpdate();
        }
    }
    
    /*private void eliminarTarjeta(Usuario u) throws SQLException {
        String sentenciaSQL = "DELETE FROM TARJETAS_VINCULADAS WHERE cliente=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, u.getCodigo());
        prepared.executeUpdate();
    }*/

    @Override
    public ArrayList<Usuario> getAll() throws SQLException {
        ArrayList<Usuario> lista = new ArrayList<>();
        String sentenciaSQL = "SELECT * FROM " + tabla + " ORDER BY codigo";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            int codigo = resultSet.getInt("codigo");
            String nombreCompleto = resultSet.getString("nombre_completo");
            LocalDate fechaNacimiento = resultSet.getDate("fecha_nacimiento").toLocalDate();
            String contraseña = resultSet.getString("contraseña");
            String email = resultSet.getString("email");
            String foto = resultSet.getString("foto");
            int telefono = resultSet.getInt("telefono");
            TipoUsuario tipoUsuario = TipoUsuario.valueOf(resultSet.getString("tipo"));
            Timestamp ultimaConexionTS = resultSet.getTimestamp("ultima_conexion");
            LocalDateTime ultimaConexion = ultimaConexionTS == null ? null : ultimaConexionTS.toLocalDateTime();
            lista.add(new Usuario(codigo, nombreCompleto, fechaNacimiento, contraseña, email, foto, telefono, tipoUsuario, ultimaConexion, getTarjetas(codigo)));
        }

        return lista;
    }

    @Override
    public Usuario getByCodigo(int codigo) throws SQLException {
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE codigo=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, codigo);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            int cod = resultSet.getInt("codigo");
            String nombreCompleto = resultSet.getString("nombre_completo");
            LocalDate fechaNacimiento = resultSet.getDate("fecha_nacimiento").toLocalDate();
            String contraseña = resultSet.getString("contraseña");
            String email = resultSet.getString("email");
            String foto = resultSet.getString("foto");
            int telefono = resultSet.getInt("telefono");
            TipoUsuario tipoUsuario = TipoUsuario.valueOf(resultSet.getString("tipo"));
            Timestamp ultimaConexionTS = resultSet.getTimestamp("ultima_conexion");
            LocalDateTime ultimaConexion = ultimaConexionTS == null ? null : ultimaConexionTS.toLocalDateTime();
            return new Usuario(cod, nombreCompleto, fechaNacimiento, contraseña, email, foto, telefono, tipoUsuario, ultimaConexion, getTarjetas(codigo));
        }
        return null;
    }
    
    public Usuario validar(String formEmail, String formPassword) throws SQLException {
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE email=? AND contraseña=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setString(1, formEmail);
        prepared.setString(2, formPassword);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            int cod = resultSet.getInt("codigo");
            String nombreCompleto = resultSet.getString("nombre_completo");
            LocalDate fechaNacimiento = resultSet.getDate("fecha_nacimiento").toLocalDate();
            String contraseña = resultSet.getString("contraseña");
            String email = resultSet.getString("email");
            String foto = resultSet.getString("foto");
            int telefono = resultSet.getInt("telefono");
            TipoUsuario tipoUsuario = TipoUsuario.valueOf(resultSet.getString("tipo"));
            Timestamp ultimaConexionTS = resultSet.getTimestamp("ultima_conexion");
            LocalDateTime ultimaConexion = ultimaConexionTS == null ? null : ultimaConexionTS.toLocalDateTime();
            return new Usuario(cod, nombreCompleto, fechaNacimiento, contraseña, email, foto, telefono, tipoUsuario, ultimaConexion, getTarjetas(cod));
        }
        
        return null;
    }
    
    public boolean tieneCesta(String cesta, Usuario usuario) throws SQLException{
        String sentenciaSQL = "SELECT count(*) as cuenta FROM CESTA WHERE nombre=? AND cliente=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setString(1, cesta);
        prepared.setInt(2, usuario.getCodigo());
        ResultSet resultSet = prepared.executeQuery();
        int comparar = resultSet.getInt("cuenta");
        if(comparar == 0){
            return false;
            
        }
        return true;
    }
    
}
