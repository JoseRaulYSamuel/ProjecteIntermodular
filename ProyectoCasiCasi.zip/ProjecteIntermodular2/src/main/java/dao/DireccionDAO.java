/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import dto.Direccion;
import dto.Usuario;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author ciclost
 */
public class DireccionDAO extends TablaDAO<Direccion>{

    public DireccionDAO() {
        this.tabla = "DIRECCION";
    }
    
    @Override
    public int actualizar(Direccion objeto) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int anyadir(Direccion d) throws SQLException {
        String sentenciaSQL = "INSERT INTO " + tabla + " VALUES(?,?,?,?,?,?)";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, d.getCodigo());
        if (d.getProvincia() == null) {
            prepared.setNull(2, java.sql.Types.VARCHAR);
        } else {
            prepared.setString(2, d.getProvincia());
        }
        prepared.setInt(3, d.getCp());
        prepared.setString(4, d.getTipo());
        prepared.setString(5, d.getDireccion());
        Usuario cliente = d.getUsuario();
        prepared.setInt(6, cliente.getCodigo());
        return prepared.executeUpdate();
    }

    @Override
    public Direccion eliminar(Direccion d) throws SQLException {
        if (d == null) {
            return null;
        } else {
            return eliminar(d.getCodigo()) != null ? d : null;
        }
    }

    @Override
    public boolean existe(Direccion d) throws SQLException {
        return existe(d.getCodigo());
    }

    @Override
    public ArrayList<Direccion> getAll() throws SQLException {
        ArrayList<Direccion> lista = new ArrayList<>();
        String sentenciaSQL = "SELECT * FROM " + tabla + " ORDER BY codigo";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            int codigo = resultSet.getInt("codigo");
            String provincia = resultSet.getString("provincia");
            int cp = resultSet.getInt("cp");
            String tipo = resultSet.getString("tipo");
            String direccion = resultSet.getString("direccion");
            Usuario cliente = new UsuarioDAO().getByCodigo(resultSet.getInt("cliente"));
            lista.add(new Direccion(codigo, direccion, tipo, provincia, cp, cliente));
        }
        return lista;
    }

    @Override
    public Direccion getByCodigo(int codigo) throws SQLException {
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE codigo=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, codigo);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            int cod = resultSet.getInt("codigo");
            String provincia = resultSet.getString("provincia");
            int cp = resultSet.getInt("cp");
            String tipo = resultSet.getString("tipo");
            String direccion = resultSet.getString("direccion");
            Usuario cliente = new UsuarioDAO().getByCodigo(resultSet.getInt("cliente"));
            return new Direccion(cod, direccion, tipo, provincia, cp, cliente);
        }
        return null;
    }
    
    public Direccion getDireccionDe(Usuario u) throws SQLException {
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE cliente=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, u.getCodigo());
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            int codigo = resultSet.getInt("codigo");
            String provincia = resultSet.getString("provincia");
            int cp = resultSet.getInt("cp");
            String tipo = resultSet.getString("tipo");
            String direccion = resultSet.getString("direccion");
            Usuario cliente = new UsuarioDAO().getByCodigo(resultSet.getInt("cliente"));
            return new Direccion(codigo, direccion, tipo, provincia, cp, cliente);
        }
        return null;
    }
    
}
