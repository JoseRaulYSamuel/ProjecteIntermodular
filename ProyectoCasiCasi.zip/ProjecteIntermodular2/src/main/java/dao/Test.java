/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import dto.Articulo;
import dto.Categoria;
import dto.Cesta;
import dto.Direccion;
import dto.Factura;
import dto.Lineacesta;
import dto.Marca;
import dto.Pedido;
import dto.Tarjeta;
import dto.TipoArticulo;
import dto.TipoUsuario;
import dto.Usuario;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;

/**
 *
 * @author ciclost
 */
public class Test {

    public static void main(String[] args) throws SQLException {
        //PRUEBA DE ARTICULODAO
        /*ArticuloDAO prueba = new ArticuloDAO();
        Categoria cat1 = new Categoria("prueba1");
        ArrayList<Categoria> categoria = new ArrayList<>();
        categoria.add(cat1);
        CategoriaDAO categoria1 = new CategoriaDAO();
        categoria1.anyadir(cat1);
        Articulo articulo = new Articulo(11111111, "rosquilla", 3, "rosquilla de fresa", null, 1, categoria, null, null, null, TipoArticulo.Dulces_Snacks);
        prueba.anyadir(articulo);*/
        //prueba.actualizar(articulo);
        
        //PRUEBA DE CATEGORIADAO
        /*Categoria cat1 = new Categoria("prueba");
        CategoriaDAO categoria1 = new CategoriaDAO();
        categoria1.anyadir(cat1);
        categoria1.eliminar(cat1);
        Categoria cat2 = new Categoria("paco");
        categoria1.anyadir(cat2);
        System.out.println(categoria1.existe("prueba"));
        System.out.println(categoria1.existe(cat2));
        ArrayList<Categoria> cate = categoria1.getAll();
        for (int i = 0; i < cate.size(); i++) {
            System.out.println(cate.get(i));
        }*/
        
        //PRUEBA DE MARCADAO
        /*Marca mar1 = new Marca("prueba");
        MarcaDAO marca1 = new MarcaDAO();
        marca1.anyadir(mar1);
        marca1.eliminar(mar1);
        Marca mar2 = new Marca("paco");
        marca1.anyadir(mar2);
        System.out.println(marca1.existe("prueba"));
        System.out.println(marca1.existe(mar2));
        ArrayList<Marca> marcas = marca1.getAll();
        for (int i = 0; i < marcas.size(); i++) {
            System.out.println(marcas.get(i));
        }*/
        
        //PRUEBA DE TARJETA
        /*Tarjeta tar1 = new Tarjeta(12345678);
        TarjetaDAO tarjeta1 = new TarjetaDAO();
        tarjeta1.anyadir(tar1);
        tarjeta1.eliminar(tar1);
        Tarjeta tar2 = new Tarjeta(87654321);
        tarjeta1.anyadir(tar2);
        System.out.println(tarjeta1.existe(tar1));
        System.out.println(tarjeta1.existe(tar2));
        ArrayList<Tarjeta> tarjetas = tarjeta1.getAll();
        for (int i = 0; i < tarjetas.size(); i++) {
            System.out.println(tarjetas.get(i));
        }*/
        Usuario u = new UsuarioDAO().getByCodigo(11111111);
        DireccionDAO dir = new DireccionDAO();
        Direccion d = dir.getDireccionDe(u);
        Cesta c = new CestaDAO().getByNombre(u.getEmail());
        Pedido p = new Pedido(12332312, LocalDateTime.now(), c, d);
        new PedidoDAO().anyadir(p);
       
    }

}
