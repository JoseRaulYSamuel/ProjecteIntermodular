/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import modelo.dto.Direccion;
import modelo.dto.MetodoPago;
import modelo.dto.Pedido;
import modelo.dto.Producto;
import modelo.dto.TipoUsuario;
import modelo.dto.Usuario;

/**
 *
 * @author jrmd
 */
public class PedidoDAO extends TablaDAO<Pedido> {

    public PedidoDAO() {
        this.tabla = "pedido";
    }

    @Override
    public int actualizar(Pedido p) throws SQLException {
        //No necesario para el proyecto
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int anyadir(Pedido p) throws SQLException {
        String sentenciaSQL = "INSERT INTO " + tabla + " VALUES(?,?,?,?,?)";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, p.getCodigo());
        prepared.setTimestamp(2, Timestamp.valueOf(p.getFecha()));
        prepared.setInt(3, p.getUsuario().getCodigo());
        Direccion direccion = p.getDireccion();
        if(direccion == null) prepared.setNull(4, java.sql.Types.INTEGER);
        else prepared.setInt(4, direccion.getCodigo());
        prepared.setString(5, p.getMetodoPago().toString());
        int resultado = prepared.executeUpdate();
        anyadirLineas(p);
        return resultado;
        
    }

    @Override
    public Pedido eliminar(Pedido p) throws SQLException {
        if (p == null) {
            return null;
        } else {
            return eliminar(p.getCodigo()) != null ? p : null;
        }
    }

    @Override
    public boolean existe(Pedido p) throws SQLException {
        return existe(p.getCodigo());
    }

    @Override
    public ArrayList<Pedido> getAll() throws SQLException {
        ArrayList<Pedido> lista = new ArrayList<>();
        String sentenciaSQL = "SELECT * FROM " + tabla + " ORDER BY codigo";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            int codigo = resultSet.getInt("codigo");
            LocalDateTime fecha = resultSet.getTimestamp("fecha").toLocalDateTime();
            Usuario usuario = new UsuarioDAO().getByCodigo(resultSet.getInt("usuario"));
            Direccion direccion = new DireccionDAO().getByCodigo(resultSet.getInt("coddir"));
            MetodoPago metodoPago = MetodoPago.valueOf(resultSet.getString("metodopago"));
            boolean facturado = estaFacturado(codigo);
            LinkedHashMap<Producto, Integer> lineasPedido = getLineas(codigo);
            lista.add(new Pedido(codigo, fecha, usuario, metodoPago, direccion, lineasPedido, facturado));
        }

        return lista;
    }

    @Override
    public Pedido getByCodigo(int codigo) throws SQLException {
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE codigo=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, codigo);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            LocalDateTime fecha = resultSet.getTimestamp("fecha").toLocalDateTime();
            Usuario usuario = new UsuarioDAO().getByCodigo(resultSet.getInt("usuario"));
            Direccion direccion = new DireccionDAO().getByCodigo(resultSet.getInt("coddir"));
            MetodoPago metodoPago = MetodoPago.valueOf(resultSet.getString("metodopago"));
            boolean facturado = estaFacturado(codigo);
            LinkedHashMap<Producto, Integer> lineasPedido = getLineas(codigo);
            return new Pedido(codigo, fecha, usuario, metodoPago, direccion, lineasPedido, facturado);
        }

        return null;
    }

    public ArrayList<Pedido> getByCodigoUsuario(int codigoUsuario) throws SQLException {
        ArrayList<Pedido> pedidos = new ArrayList<>();
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE usuario=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, codigoUsuario);
        ResultSet resultSet = prepared.executeQuery();
        Usuario usuario = new UsuarioDAO().getByCodigo(codigoUsuario);
        while (resultSet.next()) {
            int codigo = resultSet.getInt("codigo");       
            LocalDateTime fecha = resultSet.getTimestamp("fecha").toLocalDateTime();
            Direccion direccion = new DireccionDAO().getByCodigo(resultSet.getInt("coddir"));
            MetodoPago metodoPago = MetodoPago.valueOf(resultSet.getString("metodopago"));
            boolean facturado = estaFacturado(codigo);
            LinkedHashMap<Producto, Integer> lineasPedido = getLineas(codigo);
            pedidos.add(new Pedido(codigo, fecha, usuario, metodoPago, direccion, lineasPedido, facturado));
        }

        return pedidos;
    }
    
    

    public LinkedHashMap<Producto, Integer> getLineas(int codPedido) throws SQLException {
        ProductoDAO productoDAO = new ProductoDAO();
        LinkedHashMap<Producto, Integer> lineas = new LinkedHashMap<>();
        String sentenciaSQL = "SELECT producto, cantidad FROM productospedido WHERE pedido = ?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, codPedido);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            Producto producto = productoDAO.getByCodigo(resultSet.getInt("producto"));
            int cantidad = resultSet.getInt("cantidad");
            lineas.put(producto, cantidad);
        }

        return lineas;

    }

    private void anyadirLineas(Pedido p) throws SQLException {
        for (Map.Entry<Producto, Integer> entry : p.getLineasPedido().entrySet()) {
            String sentenciaSQL = "INSERT INTO productospedido VALUES(?, ?, ?)";
            PreparedStatement prepared = getPrepared(sentenciaSQL);
            prepared.setInt(1, entry.getKey().getCodigo());
            prepared.setInt(2, p.getCodigo());
            prepared.setInt(3, entry.getValue());
            prepared.executeUpdate();
        }
    }

    private void eliminarLineas(Pedido p) throws SQLException {
        String sentenciaSQL = "DELETE FROM productospedido WHERE pedido=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, p.getCodigo());
        prepared.executeUpdate();

    }

    public boolean estaFacturado(int codpedido) throws SQLException {
        String sentenciaSQL = "SELECT * FROM factura WHERE pedido=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, codpedido);
        return prepared.executeUpdate() != 0;

    }
    
    public void descontarStock(Pedido ped) {
        ProductoDAO productoDAO = new ProductoDAO();
        for (Map.Entry<Producto, Integer> linea : ped.getLineasPedido().entrySet()) {
            try {
                Producto pa = linea.getKey();
                int stock = pa.getStock() - linea.getValue();
                Producto pn = new Producto(pa.getCodigo(), pa.getNombre(), pa.getDescripcion(), pa.getPrecio(), pa.getUnidadDeMedida(), pa.getIva(), stock, pa.getStockMinimo(), pa.getFoto(), pa.getUsuarioCrea(), pa.getFechaCreacion(), pa.getUsuarioModifica(), pa.getFechaModificacion(), pa.getCategorias());
                productoDAO.actualizar(pn);
            } catch (SQLException ex) {
                System.out.println("Error SQL");
            }
        }
    }

}
