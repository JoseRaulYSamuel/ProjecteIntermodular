/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo.dao;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import modelo.dto.TipoUsuario;
import modelo.dto.Usuario;

/**
 *
 * @author jrmd
 */
public class UsuarioDAO extends TablaDAO<Usuario> {

    public UsuarioDAO() {
        this.tabla = "usuario";
    }

    @Override
    public int actualizar(Usuario u) {
        // NO SE UTILIZA EN NUESTRO PROYECTO
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public int anyadir(Usuario u) throws SQLException {
        String sentenciaSQL = "INSERT INTO " + tabla + " VALUES(?,?,?,?,?,?,?,?)";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, u.getCodigo());
        prepared.setString(2, u.getNombreCompleto());
        prepared.setString(3, u.getEmail());
        prepared.setString(4, u.getContrasenya());
        prepared.setDate(5, Date.valueOf(u.getFechaNacimiento()));
        prepared.setInt(6, u.getTelefono());
        prepared.setString(7, String.valueOf(u.getTipoUsuario()));
        LocalDateTime ultimaConexion = u.getUltimaConexion();
        if (ultimaConexion == null) {
            prepared.setNull(8, java.sql.Types.TIMESTAMP);
        } else {
            prepared.setTimestamp(8, Timestamp.valueOf(ultimaConexion));
        }
        return prepared.executeUpdate();

    }

    @Override
    public Usuario eliminar(Usuario u) throws SQLException {
        if (u == null) {
            return null;
        } else {
            return eliminar(u.getCodigo()) != null ? u : null;
        }
    }

    @Override
    public boolean existe(Usuario u) throws SQLException {
        return existe(u.getCodigo());
    }


    @Override
    public ArrayList<Usuario> getAll() throws SQLException {
        ArrayList<Usuario> lista = new ArrayList<>();
        String sentenciaSQL = "SELECT * FROM " + tabla + " ORDER BY codigo";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            int codigo = resultSet.getInt("codigo");
            String nombreCompleto = resultSet.getString("nombrecompleto");
            String contrasenya = resultSet.getString("contrasenya");
            String email = resultSet.getString("email");
            LocalDate fechaNacimiento = resultSet.getDate("fnacimiento").toLocalDate();
            int telefono = resultSet.getInt("telefono");
            TipoUsuario tipoUsuario = TipoUsuario.valueOf(resultSet.getString("tipo"));
            Timestamp ultimaConexionTS = resultSet.getTimestamp("ultconex");
            LocalDateTime ultimaConexion = ultimaConexionTS == null ? null : ultimaConexionTS.toLocalDateTime();
            lista.add(new Usuario(codigo, nombreCompleto, contrasenya, email, fechaNacimiento, telefono, tipoUsuario, ultimaConexion));
        }

        return lista;
    }
    @Override
    public Usuario getByCodigo(int codigo) throws SQLException {
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE codigo=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, codigo);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            String nombreCompleto = resultSet.getString("nombrecompleto");
            String contrasenya = resultSet.getString("contrasenya");
            String email = resultSet.getString("email");
            LocalDate fechaNacimiento = resultSet.getDate("fnacimiento").toLocalDate();
            int telefono = resultSet.getInt("telefono");
            TipoUsuario tipoUsuario = TipoUsuario.valueOf(resultSet.getString("tipo"));
            Timestamp ultimaConexionTS = resultSet.getTimestamp("ultconex");
            LocalDateTime ultimaConexion = ultimaConexionTS == null ? null : ultimaConexionTS.toLocalDateTime();
            return new Usuario(codigo, nombreCompleto, contrasenya, email, fechaNacimiento, telefono, tipoUsuario, ultimaConexion);
        }
        
        return null;
    }
    
    public Usuario validar(String formEmail, String formPassword) throws SQLException {
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE email=? AND contrasenya=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setString(1, formEmail);
        prepared.setString(2, formPassword);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            int codigo = resultSet.getInt("codigo");
            String nombreCompleto = resultSet.getString("nombrecompleto");
            String contrasenya = resultSet.getString("contrasenya");
            String email = resultSet.getString("email");
            LocalDate fechaNacimiento = resultSet.getDate("fnacimiento").toLocalDate();
            int telefono = resultSet.getInt("telefono");
            TipoUsuario tipoUsuario = TipoUsuario.valueOf(resultSet.getString("tipo"));
            Timestamp ultimaConexionTS = resultSet.getTimestamp("ultconex");
            LocalDateTime ultimaConexion = ultimaConexionTS == null ? null : ultimaConexionTS.toLocalDateTime();
            return new Usuario(codigo, nombreCompleto, contrasenya, email, fechaNacimiento, telefono, tipoUsuario, ultimaConexion);
        }
        
        return null;
    }

}
