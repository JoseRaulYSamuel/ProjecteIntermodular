/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author jrmd
 */
public class Usuario {

    private final int codigo;
    private final String nombreCompleto;
    private final String contrasenya;
    private final String email;
    private final LocalDate fechaNacimiento;
    private final int telefono;
    private final TipoUsuario tipoUsuario;
    private final LocalDateTime ultimaConexion;

    public Usuario(int codigo, String nombreCompleto, String contrasenya, String email, LocalDate fechaNacimiento, int telefono, TipoUsuario tipoUsuario, LocalDateTime ultimaConexion) {
        this.codigo = codigo;
        this.nombreCompleto = nombreCompleto;
        this.contrasenya = contrasenya;
        this.email = email;
        this.fechaNacimiento = fechaNacimiento;
        this.telefono = telefono;
        this.tipoUsuario = (tipoUsuario == null) ? TipoUsuario.Anónimo : tipoUsuario;
        this.ultimaConexion = ultimaConexion;
    }

    public Usuario(Usuario u) {
        this(u.codigo, u.nombreCompleto, u.contrasenya, u.email, u.fechaNacimiento, u.telefono, u.tipoUsuario, u.ultimaConexion);
    }

    public int getCodigo() {
        return codigo;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public String getContrasenya() {
        return contrasenya;
    }

    public String getEmail() {
        return email;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public int getTelefono() {
        return telefono;
    }

    public TipoUsuario getTipoUsuario() {
        return tipoUsuario;
    }
    
    public boolean isAdmin(){
        return tipoUsuario == TipoUsuario.Administrador;
    }
    
     public boolean isCliente(){
        return tipoUsuario == TipoUsuario.Cliente;
    }
     
     public boolean isAnonimo(){
        return tipoUsuario == TipoUsuario.Anónimo;
    }


    public LocalDateTime getUltimaConexion() {
        return ultimaConexion;
    }

    public List<Direccion> getListaDirecciones(List<Direccion> original) {
        List<Direccion> lista = new ArrayList<>();
        for (Direccion d : original) {
            if (d.perteneceA(this)) {
                lista.add(d);
            }
        }
        return lista;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 83 * hash + this.codigo;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Usuario other = (Usuario) obj;
        return this.codigo == other.codigo;
    }

    @Override
    public String toString() {
        return "Usuario{" + "codigo=" + codigo + ", nombreCompleto=" + nombreCompleto + ", contrasenya=" + contrasenya + ", email=" + email + ", fechaNacimiento=" + fechaNacimiento + ", telefono=" + telefono + ", tipoUsuario=" + tipoUsuario + ", ultimaConexion=" + ultimaConexion + '}';
    }
    
    

}
