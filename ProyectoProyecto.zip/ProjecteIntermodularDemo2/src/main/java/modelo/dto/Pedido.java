/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo.dto;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import modelo.dao.ProductoDAO;

/**
 *
 * @author jrmd
 */
public class Pedido {

    private final int codigo;
    private final LocalDateTime fecha;
    private final Usuario usuario;
    private final Direccion direccion; 
    private final MetodoPago metodoPago;
    private final LinkedHashMap<Producto,Integer> lineasPedido;
    private final boolean facturado;

    public Pedido(int codigo, LocalDateTime fecha, Usuario usuario, MetodoPago metodoPago, Direccion direccion, LinkedHashMap<Producto, Integer> lineasPedido, boolean facturado) throws RuntimeException {
        this.codigo = codigo;
        this.fecha = fecha;
        this.usuario = usuario;
        this.metodoPago = metodoPago;
        this.direccion = direccion;
        this.lineasPedido = lineasPedido;
        this.facturado = facturado;

    }

    public int getCodigo() {
        return codigo;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    public MetodoPago getMetodoPago() {
        return metodoPago;
    }

    public Direccion getDireccion() throws RuntimeException {
        return direccion;
    }

    public LinkedHashMap<Producto, Integer> getLineasPedido() {
        return new LinkedHashMap<>(lineasPedido);
    }

    public Usuario getUsuario() {
        return usuario;
    }
    

    public double getTotalConIVA(){
        double total = 0;
        for(Entry<Producto, Integer> entry: lineasPedido.entrySet()){
            total += entry.getValue() * entry.getKey().getPrecioConIva();
        }
        return total;
    }
    
    public double getTotalSinIVA(){
        double total = 0;
        for(Entry<Producto, Integer> entry: lineasPedido.entrySet()){
            total += entry.getValue() * entry.getKey().getPrecio();
        }
        return total;
    }

    public boolean isFacturado() {
        return facturado;
    }
   

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 47 * hash + this.codigo;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Pedido other = (Pedido) obj;
        return this.codigo == other.codigo;
    }

    @Override
    public String toString() {
        return "Pedido{" + "codigo=" + codigo + ", fecha=" + fecha + ", usuario=" + usuario + ", direccion=" + direccion + ", metodoPago=" + metodoPago + ", lineasPedido=" + lineasPedido + ", facturado=" + facturado + '}';
    }

    public boolean revisarStock() {
        for(Entry<Producto, Integer> linea: lineasPedido.entrySet()){
            if(linea.getKey().getStock() - linea.getValue() < linea.getKey().getStockMinimo()) return false;
        }
        return true;
    }
    
    public boolean perteneceAUsuario(Usuario u){
        return this.usuario.equals(u);
    }

   
    
    
    
    
}
