/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package test;

import modelo.dto.Producto;
import modelo.dto.MetodoPago;
import modelo.dto.Categoria;
import modelo.dto.Usuario;
import modelo.dto.TipoUsuario;
import modelo.dto.Pedido;
import modelo.dto.Direccion;
import modelo.dao.DireccionDAO;
import modelo.dao.PedidoDAO;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelo.dao.FacturaDAO;

/**
 *
 * @author jrmd
 */
public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            Usuario usu1 = new Usuario(1, "Federico Cepeda", "abcde", "fede@empresa.es", LocalDate.now(), 965874512, TipoUsuario.Cliente, null);
            Usuario usu2 = new Usuario(2, "Adelaida Buendia", "@@d2A", "ade@lai.da", LocalDate.of(2020, Month.MARCH, 10), 668445719, TipoUsuario.Administrador, LocalDateTime.of(2022, Month.MARCH, 1, 17, 30));
            //UsuarioDAO usuarioDAO = new UsuarioDAO();
            //usuarioDAO.anyadir(usu1);
            //usuarioDAO.anyadir(usu2);
            //usuarioDAO = null;
            
            Categoria cat1 = new Categoria(1, "Sobremesa");
            Categoria cat2 = new Categoria(2, "Portátiles");
            Categoria cat3 = new Categoria(3, "Móviles");
            Categoria cat4 = new Categoria(4, "Tecnología");
            Categoria otra = new Categoria(23, "Final");
            //CategoriaDAO categoriaDAO = new CategoriaDAO();
            //categoriaDAO.anyadir(cat1);
            //categoriaDAO.anyadir(cat2);
            //categoriaDAO.anyadir(cat3);
            //categoriaDAO.anyadir(cat4);
            
            Direccion dir1 = new Direccion(1, usu1, "Calle mayor 25, 2ºA", "Petrer", "Alicante", 03610);
            Direccion dir2 = new Direccion(2, usu2, "Calle bailén 2", "Villena", "Alicante", 03054);
            Direccion dir3 = new Direccion(44, usu2, "Avda. de la Libertad 11, 5ºC", "Elche", "Alicante", 03365);
            DireccionDAO direccionDAO = new DireccionDAO();
            //direccionDAO.anyadir(dir1);
            //direccionDAO.actualizar(dir2);
            //direccionDAO.eliminar(dir2);

            
            LinkedHashSet<Categoria> categoP1 = new LinkedHashSet<Categoria>();
            categoP1.add(cat1);
            categoP1.add(cat4);

            Producto p1 = new Producto(87, "Alto", "Muy barato", 0.54, "KG", 10, 20, 1, null, usu2, LocalDateTime.of(2020, Month.MARCH, 14, 22, 55), null, LocalDateTime.now(), categoP1);
            Producto p2 = new Producto(78, "Bajo", "Muy caro", 9.5, "unidades", 21, 50, 1, null, usu2, LocalDateTime.of(2020, Month.MARCH, 14, 22, 55), null, LocalDateTime.now(), categoP1);

            LinkedHashMap<Producto, Integer> lp= new LinkedHashMap<>();
            lp.put(p1, 3);
            lp.put(p2, 2);
            
            Pedido ped1 = new Pedido(10, LocalDateTime.now(), usu2, MetodoPago.tarjeta, dir2, lp, false);
            //System.out.println(new PedidoDAO().anyadir(ped1));
            //System.out.println(new ProductoDAO().actualizar(p1));

            ArrayList<Pedido> peds = new PedidoDAO().getAll();
            peds.forEach(System.out::println);
            
            //Factura f1 = new Factura(1, LocalDateTime.now(), dir2, ped1);
            new FacturaDAO().getAll().forEach(System.out::println);
            

        } catch (SQLException ex) {
            Logger.getLogger(NewMain.class.getName()).log(Level.SEVERE, null, ex);
        }

        /*
        
        
        Producto pro1 = new Producto(1, "ASUS 2315", "Ordenador ofimática", 251.15, "ud", .21, 10, 2, "fotos/a2315.jpg", null, LocalDateTime.now(), null, null, new HashSet<Categoria>(Arrays.asList(cat1)));
        Producto pro2 = new Producto(2, "HP 238", "Portátil gaming", 789.35, "ud", .21, 10, 2, "fotos/hp238.jpg", null, LocalDateTime.now(), null, null, new HashSet<Categoria>(Arrays.asList(cat2)));
        System.out.println(pro1.getPrecioConIva());
        System.out.println(pro2.getPrecioConIva());
         */
        try {
            /*Direccion dir1 = new Direccion(usu1, 26, "Calle Mayor", "Petrer", "Alicante", 03610);
            HashMap lineasPedido1 = new HashMap<>();
            lineasPedido1.put(pro1, 2);
            lineasPedido1.put(pro2, 1);
            Pedido ped1 = new Pedido(1, LocalDateTime.now(), usu1, MetodoPago.PAYPAL, dir1, lineasPedido1, null);
            System.out.println(ped1.getTotal());
            ped1.generarFactura(null);
            Factura fact1 = ped1.getFactura();
            System.out.println(fact1.getDireccion().getPoblacion());
            for(Producto p: fact1.getPedidoAsociado().getLineasPedido().keySet()){
                System.out.println("Producto: " + p.getNombre() + " - Cantidad: " + fact1.getPedidoAsociado().getLineasPedido().get(p));
            }
             */

            //System.out.println(new DireccionDAO().obtenerTodos());

            /*
            UsuarioDAO usuarioDAO = new UsuarioDAO();
            usuarioDAO.getAllUsuarios().forEach(u -> System.out.println(u.getContrasenya() + " " + u.getEmail() + " " + u.getFechaNacimiento() + " " + u.getTipoUsuario() + " " + u.getUltimaConexion().minus(Period.of(1, 52, 0))));

            cr.stop();
            cr.imprimir("c");
             */
        } catch (Exception ex) {
            Logger.getLogger(NewMain.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
