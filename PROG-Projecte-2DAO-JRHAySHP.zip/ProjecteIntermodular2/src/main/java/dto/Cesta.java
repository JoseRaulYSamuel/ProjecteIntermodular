/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dto;

import java.util.ArrayList;
import java.util.Objects;

/**
 *
 * @author s4mu3
 */
public class Cesta {
    private String nombre;
    private Usuario usuario;
    private ArrayList<Lineacesta> lineas;

    public Cesta(String nombre, Usuario usuario, ArrayList<Lineacesta> lineas) {
        this.nombre = nombre;
        this.usuario = usuario;
        this.lineas = lineas;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public ArrayList<Lineacesta> getLineas() {
        return lineas;
    }

    public void setLineas(ArrayList<Lineacesta> lineas) {
        this.lineas = lineas;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 89 * hash + Objects.hashCode(this.nombre);
        hash = 89 * hash + Objects.hashCode(this.usuario);
        hash = 89 * hash + Objects.hashCode(this.lineas);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Cesta other = (Cesta) obj;
        if (!Objects.equals(this.nombre, other.nombre)) {
            return false;
        }
        if (!Objects.equals(this.usuario, other.usuario)) {
            return false;
        }
        return Objects.equals(this.lineas, other.lineas);
    }
    
    public double getTotal(){
        double acum = 0;
        for (Lineacesta linea : lineas) {
            acum = acum + linea.getTotalLinea();
        }
        return acum;
    }
}
