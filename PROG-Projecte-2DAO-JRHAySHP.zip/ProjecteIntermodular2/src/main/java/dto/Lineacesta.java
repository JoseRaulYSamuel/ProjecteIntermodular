/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dto;

import java.util.Objects;

/**
 *
 * @author s4mu3
 */
public class Lineacesta {
    private int cantidad;
    private double precio;
    private Articulo articulo;

    public Lineacesta(int cantidad, double precio, Articulo articulo) {
        this.cantidad = cantidad;
        this.precio = precio;
        this.articulo = articulo;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public Articulo getArticulo() {
        return articulo;
    }

    public void setArticulo(Articulo articulo) {
        this.articulo = articulo;
    }
    
    public double getTotalLinea(){
        return this.cantidad * this.getArticulo().getPvp();
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 31 * hash + this.cantidad;
        hash = 31 * hash + (int) (Double.doubleToLongBits(this.precio) ^ (Double.doubleToLongBits(this.precio) >>> 32));
        hash = 31 * hash + Objects.hashCode(this.articulo);
        return hash;
    }

    

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Lineacesta other = (Lineacesta) obj;
        if (this.cantidad != other.cantidad) {
            return false;
        }
        if (this.precio != other.precio) {
            return false;
        }
        return Objects.equals(this.articulo, other.articulo);
    }
    
}
