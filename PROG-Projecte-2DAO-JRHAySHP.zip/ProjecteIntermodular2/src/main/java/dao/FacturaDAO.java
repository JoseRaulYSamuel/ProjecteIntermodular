/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import dto.Direccion;
import dto.Factura;
import dto.Pedido;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;

/**
 *
 * @author ciclost
 */
public class FacturaDAO extends TablaDAO<Factura>{
    
    public FacturaDAO() {
        this.tabla = "FACTURA";
    }

    @Override
    public int actualizar(Factura objeto) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int anyadir(Factura f) throws SQLException {
        String sentenciaSQL = "INSERT INTO " + tabla + " VALUES(?,?,?,?)";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, f.getCodigo());
        prepared.setTimestamp(2, Timestamp.valueOf(f.getFecha()));  
        Direccion direccion = f.getDireccion();
        prepared.setInt(3, direccion.getCodigo());
        Pedido pedido = f.getPedido();
        prepared.setInt(4, pedido.getCodigo());
        return prepared.executeUpdate();
    }

    @Override
    public Factura eliminar(Factura f) throws SQLException {
        if (f == null) {
            return null;
        } else {
            return eliminar(f.getCodigo()) != null ? f : null;
        }
    }

    @Override
    public boolean existe(Factura f) throws SQLException {
        return existe(f.getCodigo());
    }

    @Override
    public ArrayList<Factura> getAll() throws SQLException {
        ArrayList<Factura> lista = new ArrayList<>();
        String sentenciaSQL = "SELECT * FROM " + tabla + " ORDER BY codigo";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            int codigo = resultSet.getInt("codigo");
            Timestamp fechaTS = resultSet.getTimestamp("fecha");
            LocalDateTime fecha = fechaTS == null ? null : fechaTS.toLocalDateTime();
            Direccion direccion = new DireccionDAO().getByCodigo(resultSet.getInt("direccion"));
            Pedido pedido = new PedidoDAO().getByCodigo(resultSet.getInt("pedido"));
            lista.add(new Factura(codigo, fecha, pedido, direccion));
        }
        return lista;
    }

    @Override
    public Factura getByCodigo(int codigo) throws SQLException {
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE codigo=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, codigo);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            int cod = resultSet.getInt("codigo");
            Timestamp fechaTS = resultSet.getTimestamp("fecha");
            LocalDateTime fecha = fechaTS == null ? null : fechaTS.toLocalDateTime();
            Direccion direccion = new DireccionDAO().getByCodigo(resultSet.getInt("direccion"));
            Pedido pedido = new PedidoDAO().getByCodigo(resultSet.getInt("pedido"));
            return new Factura(codigo, fecha, pedido, direccion);
        }
        return null;
    }
    
    public ArrayList<Factura> getFacturasDe(Direccion d) throws SQLException {
        ArrayList<Factura> lista = new ArrayList<>();
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE direccion=? ORDER BY direccion";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, d.getCodigo());
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            int codigo = resultSet.getInt("codigo");
            Timestamp fechaTS = resultSet.getTimestamp("fecha");
            LocalDateTime fecha = fechaTS == null ? null : fechaTS.toLocalDateTime();
            Direccion direccion = new DireccionDAO().getByCodigo(resultSet.getInt("direccion"));
            Pedido pedido = new PedidoDAO().getByCodigo(resultSet.getInt("pedido"));
            lista.add(new Factura(codigo, fecha, pedido, direccion));
        }
        return lista;
    }
}
