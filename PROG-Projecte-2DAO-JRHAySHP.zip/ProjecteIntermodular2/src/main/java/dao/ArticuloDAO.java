/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import dto.Articulo;
import dto.Categoria;
import dto.Marca;
import dto.TipoArticulo;
import dto.Usuario;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author ciclost
 */

public class ArticuloDAO extends TablaDAO<Articulo>{
    
    public ArticuloDAO(){
        this.tabla = "ARTICULO";
    }
    
    @Override
    public int actualizar(Articulo a) throws SQLException {
        String sentenciaSQL = "UPDATE " + tabla + " SET Pvp=?, nombre=?, descripcion=?, foto=?, cantidad=?, marca=?, creador=?, modificador=?, tipo=? WHERE codigo=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setDouble(1, a.getPvp());
        prepared.setString(2, a.getNombre());
        prepared.setString(3, a.getDescripcion());
        if (a.getFoto() == null) {
            prepared.setNull(4, java.sql.Types.VARCHAR);
        } else {
            prepared.setString(4, a.getFoto());
        }
        prepared.setInt(5, a.getCantidad());
        Marca marca = a.getMarca();
        if (marca == null) {
            prepared.setNull(6, java.sql.Types.VARCHAR);
        } else {
            prepared.setString(6, marca.getNombre());
        }
        Usuario usuarioCreador = a.getCreador();
        if (usuarioCreador == null) {
            prepared.setNull(7, java.sql.Types.INTEGER);
        } else {
            prepared.setInt(7, usuarioCreador.getCodigo());
        }
        Usuario usuarioModificador = a.getModificador();
        if (usuarioModificador == null) {
            prepared.setNull(8, java.sql.Types.INTEGER);
        } else {
            prepared.setInt(8, usuarioModificador.getCodigo());
        }
        TipoArticulo Tipo = a.getTipo();
        if (Tipo == null) {
            prepared.setNull(9, java.sql.Types.VARCHAR);
        } else {
            prepared.setString(9, Tipo.toString());
        }
        prepared.setInt(10, a.getCodigo());
        int resultado = prepared.executeUpdate();
        if (resultado > 0) {
            eliminarCategorias(a);
            anyadirCategorias(a);
        }
        return resultado;
    }

    @Override
    public int anyadir(Articulo a) throws SQLException {
        String sentenciaSQL = "INSERT INTO " + tabla + " VALUES(?,?,?,?,?,?,?,?,?,?)";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, a.getCodigo());
        prepared.setDouble(2, a.getPvp());
        prepared.setString(3, a.getNombre());
        prepared.setString(4, a.getDescripcion());
        if (a.getFoto() == null) {
            prepared.setNull(5, java.sql.Types.VARCHAR);
        } else {
            prepared.setString(5, a.getFoto());
        }
        prepared.setInt(6, a.getCantidad());
        Marca marca = a.getMarca();
        if (marca == null) {
            prepared.setNull(7, java.sql.Types.VARCHAR);
        } else {
            prepared.setString(7, marca.getNombre());
        }
        Usuario usuarioCreador = a.getCreador();
        if (usuarioCreador == null) {
            prepared.setNull(8, java.sql.Types.INTEGER);
        } else {
            prepared.setInt(8, usuarioCreador.getCodigo());
        }
        Usuario usuarioModificador = a.getModificador();
        if (usuarioModificador == null) {
            prepared.setNull(9, java.sql.Types.INTEGER);
        } else {
            prepared.setInt(9, usuarioModificador.getCodigo());
        }
        TipoArticulo Tipo = a.getTipo();
        if (Tipo == null) {
            prepared.setNull(10, java.sql.Types.VARCHAR);
        } else {
            prepared.setString(10, Tipo.toString());
        }
        int resultado = prepared.executeUpdate();
        anyadirCategorias(a);
        return resultado;
    }

    @Override
    public Articulo eliminar(Articulo a) throws SQLException {
        if (a == null) {
            return null;
        } else {
            return eliminar(a.getCodigo()) != null ? a : null;
        }
    }

    @Override
    public boolean existe(Articulo a) throws SQLException {
        return existe(a.getCodigo());
    }

    @Override
    public ArrayList<Articulo> getAll() throws SQLException {
        ArrayList<Articulo> lista = new ArrayList<>();
        String sentenciaSQL = "SELECT * FROM " + tabla + " ORDER BY codigo";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            int cod = resultSet.getInt("codigo");
            double pvp = resultSet.getDouble("pvp");
            String nombre = resultSet.getString("nombre");
            String descripcion = resultSet.getString("descripcion");
            String foto = resultSet.getString("foto");
            int cantidad = resultSet.getInt("cantidad");
            Marca marca = new MarcaDAO().getByNombre(resultSet.getString("nombre"));
            Usuario usuCrea = new UsuarioDAO().getByCodigo(resultSet.getInt("creador"));
            Usuario usuMod = new UsuarioDAO().getByCodigo(resultSet.getInt("modificador"));
            TipoArticulo tipo = TipoArticulo.valueOf(resultSet.getString("tipo"));
            lista.add(new Articulo(cod, nombre, pvp, descripcion, foto, cantidad, getCategorias(cod), marca, usuMod, usuMod, tipo));
        }
        return lista;
    }

    @Override
    public Articulo getByCodigo(int codigo) throws SQLException {
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE codigo=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, codigo);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            int cod = resultSet.getInt("codigo");
            double pvp = resultSet.getDouble("pvp");
            String nombre = resultSet.getString("nombre");
            String descripcion = resultSet.getString("descripcion");
            String foto = resultSet.getString("foto");
            int cantidad = resultSet.getInt("cantidad");
            Marca marca = new MarcaDAO().getByNombre(resultSet.getString("nombre"));
            Usuario usuCrea = new UsuarioDAO().getByCodigo(resultSet.getInt("creador"));
            Usuario usuMod = new UsuarioDAO().getByCodigo(resultSet.getInt("modificador"));
            TipoArticulo tipo = TipoArticulo.valueOf(resultSet.getString("tipo"));
            
            return new Articulo(cod, nombre, pvp, descripcion, foto, cantidad, getCategorias(codigo), marca, usuMod, usuMod, tipo);
        }
        return null;
    }
    
    public ArrayList<Categoria> getCategorias(int codigo) throws SQLException{
        CategoriaDAO categoriaDAO = new CategoriaDAO();
        ArrayList<Categoria> categorias = new ArrayList<>();
        String sentenciaSQL = "SELECT categoria FROM CATEGORIA_DE_ARTICULO WHERE ARTICULO = ?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, codigo);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            Categoria categoria = categoriaDAO.getByNombre(resultSet.getString("categoria"));
            categorias.add(categoria);
        }
        return categorias;
    }
    
    private void anyadirCategorias(Articulo a) throws SQLException {
        for (Categoria c : a.getCategorias()) {
            String sentenciaSQL = "INSERT INTO categoria_de_articulo VALUES(?, ?)";
            PreparedStatement prepared = getPrepared(sentenciaSQL);
            prepared.setString(1, c.getNombre());
            prepared.setInt(2, a.getCodigo());
            prepared.executeUpdate();
        }
    }

    private void eliminarCategorias(Articulo a) throws SQLException {
        String sentenciaSQL = "DELETE FROM categoria_de_articulo WHERE articulo=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, a.getCodigo());
        prepared.executeUpdate();

    }
    
    public ArrayList<Articulo> getByTipo(String tipo) throws SQLException {
        if(tipo == null){
            return getAll();
        }
        ArrayList<Articulo> lista = new ArrayList<>();
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE tipo like ? ORDER BY codigo";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setString(1, tipo);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            int cod = resultSet.getInt("codigo");
            double pvp = resultSet.getDouble("pvp");
            String nombre = resultSet.getString("nombre");
            String descripcion = resultSet.getString("descripcion");
            String foto = resultSet.getString("foto");
            int cantidad = resultSet.getInt("cantidad");
            Marca marca = new MarcaDAO().getByNombre(resultSet.getString("nombre"));
            Usuario usuCrea = new UsuarioDAO().getByCodigo(resultSet.getInt("creador"));
            Usuario usuMod = new UsuarioDAO().getByCodigo(resultSet.getInt("modificador"));
            TipoArticulo tipo1 = TipoArticulo.valueOf(resultSet.getString("tipo"));
            lista.add(new Articulo(cod, nombre, pvp, descripcion, foto, cantidad, getCategorias(cod), marca, usuMod, usuMod, tipo1));
        }
      
        return lista;
        
    }
    
}
