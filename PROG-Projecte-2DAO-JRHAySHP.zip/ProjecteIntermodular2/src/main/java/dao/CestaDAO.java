/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import dto.Articulo;
import dto.Cesta;
import dto.Lineacesta;
import dto.Usuario;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Optional;

/**
 *
 * @author ciclost
 */
public class CestaDAO extends TablaDAO<Cesta>{

    public CestaDAO() {
        this.tabla = "CESTA";
    }
    
    @Override
    public int actualizar(Cesta objeto) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int anyadir(Cesta c) throws SQLException {
        String sentenciaSQL = "INSERT INTO " + tabla + " VALUES(?,?)";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setString(1, c.getNombre());
        Usuario usuario = c.getUsuario();
        prepared.setInt(2, usuario.getCodigo());
        int resultado = prepared.executeUpdate();
        return resultado;
    }

    @Override
    public Cesta eliminar(Cesta c) throws SQLException {
        String sentenciaSQL = "DELETE FROM " + tabla + " WHERE nombre=? AND cliente=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setString(1, c.getNombre());
        Usuario usuario = c.getUsuario();
        prepared.setInt(2, usuario.getCodigo());
        prepared.executeUpdate();
        return c;
    }
    
    public boolean existe(String nombre) throws SQLException{
        return this.getNombreDe(nombre).isPresent();
    }

    @Override
    public boolean existe(Cesta c) throws SQLException {
        return existe(c.getNombre());
    }

    @Override
    public ArrayList<Cesta> getAll() throws SQLException {
        ArrayList<Cesta> listaCestas = new ArrayList<>();
        String sentenciaSQL = "SELECT * FROM " + tabla + " ORDER BY cliente";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            String nombre = resultSet.getString("nombre");
            Usuario cliente = new UsuarioDAO().getByCodigo(resultSet.getInt("cliente"));
            listaCestas.add(new Cesta(nombre, cliente, getLineas(nombre, cliente.getCodigo())));
        }
        
        return listaCestas;
    }

    @Override
    public Cesta getByCodigo(int codigo) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    public Optional<String> getNombreDe(String nombre) throws SQLException {
        String sentenciaSQL = "SELECT nombre FROM " + tabla + " WHERE nombre=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setString(1, nombre);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            return Optional.of(resultSet.getString("nombre"));
        }
        
        return Optional.empty();
    }
    
    public ArrayList<Lineacesta> getLineas(String nombreCest,int codigo) throws SQLException{
        ArticuloDAO articuloDAO = new ArticuloDAO();
        ArrayList<Lineacesta> lineasCesta = new ArrayList<>();
        String sentenciaSQL = "SELECT * FROM ARTICULO_A_CESTA WHERE CESTA = ? AND CLIENTE = ?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setString(1, nombreCest);
        prepared.setInt(2, codigo);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            double precio = resultSet.getDouble("precio");
            int cantidad = resultSet.getInt("cantidad");
            Articulo articulo = articuloDAO.getByCodigo(resultSet.getInt("articulo"));
            lineasCesta.add(new Lineacesta(cantidad, precio, articulo));
        }
        return lineasCesta;
    }
    
    public void anyadirLinea(Cesta c) throws SQLException {
        for (Lineacesta l : c.getLineas()) {
            String sentenciaSQL = "INSERT INTO ARTICULO_A_CESTA VALUES(?, ?, ?, ?, ?)";
            PreparedStatement prepared = getPrepared(sentenciaSQL);
            prepared.setInt(1, l.getArticulo().getCodigo());
            prepared.setString(2, c.getNombre());
            prepared.setInt(3, c.getUsuario().getCodigo());
            prepared.setDouble(4, l.getPrecio());
            prepared.setInt(5, l.getCantidad());
            prepared.executeUpdate();
        }
    }
    
    public void anyadirLinea2(Lineacesta l, Cesta c) throws SQLException {
            /*String sentenciaSQL = "SELECT ARTICULO FROM ARTICULO_A_CESTA WHERE CESTA = ? AND CLIENTE = ?";
            PreparedStatement prepared = getPrepared(sentenciaSQL);
            prepared.setString(1, c.getNombre());
            prepared.setInt(2, c.getUsuario().getCodigo());
            ResultSet resultSet = prepared.executeQuery();
            int aux = resultSet.getInt(0);
            if( aux == l.getArticulo().getCodigo()){
                String sentenciaSQL1 = "UPDATE ARTICULO_A_CESTA SET CANTIDAD=? WHERE ARTICULO=?, CESTA=?, CLIENTE=?, PRECIO=?";
                PreparedStatement prepared1 = getPrepared(sentenciaSQL1);
                prepared1.setInt(2, l.getArticulo().getCodigo());
                prepared1.setString(3, c.getNombre());
                prepared1.setInt(4, c.getUsuario().getCodigo());
                prepared1.setDouble(5, l.getPrecio());
                prepared1.setInt(1, l.getCantidad());
                prepared1.executeUpdate();
            }
            else{*/
        
                String sentenciaSQL2 = "INSERT INTO ARTICULO_A_CESTA VALUES(?, ?, ?, ?, ?)";
                PreparedStatement prepared2 = getPrepared(sentenciaSQL2);
                prepared2.setInt(1, l.getArticulo().getCodigo());
                prepared2.setString(2, c.getNombre());
                prepared2.setInt(3, c.getUsuario().getCodigo());
                prepared2.setDouble(4, l.getPrecio());
                prepared2.setInt(5, l.getCantidad());
                prepared2.executeUpdate();
            /*}*/
        
    }
    
    public Cesta getByNombre(String nombre) throws SQLException {
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE nombre=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setString(1, nombre);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            String nom = resultSet.getString("nombre");
            Usuario cliente = new UsuarioDAO().getByCodigo(resultSet.getInt("cliente"));
            return new Cesta(nom, cliente, getLineas(nombre, cliente.getCodigo()));
        }

        return null;
    }
    
    public void eliminarLinea(int cod, Cesta cesta) throws SQLException{
        String sentenciaSQL = "DELETE FROM ARTICULO_A_CESTA WHERE ARTICULO=? AND CESTA=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, cod);
        prepared.setString(2, cesta.getNombre());
        prepared.executeUpdate();
    }
    
    public void actualizarLinea(Lineacesta l, Cesta c) throws SQLException {
        String sentenciaSQL1 = "UPDATE ARTICULO_A_CESTA SET CANTIDAD=? WHERE ARTICULO=? and CESTA=? and CLIENTE=? and PRECIO=?";
                PreparedStatement prepared1 = getPrepared(sentenciaSQL1);
                prepared1.setInt(2, l.getArticulo().getCodigo());
                prepared1.setString(3, c.getNombre());
                prepared1.setInt(4, c.getUsuario().getCodigo());
                prepared1.setDouble(5, l.getPrecio());
                prepared1.setInt(1, l.getCantidad());
                prepared1.executeUpdate();
    }
}
