/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dto;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Objects;

/**
 *
 * @author s4mu3
 */
public class Usuario {
    private int codigo;
    private String nombreCompleto;
    private LocalDate fechNac;      //Es opcional.
    private String contraseña;
    private String email;           //Es un valor no nulo.
    private String foto;            //Es opcional.
    private int telefono;
    private TipoUsuario tipo;
    private LocalDateTime ultConexion;
    private ArrayList<Tarjeta> tarjetas;

    public Usuario(int codigo, String nombreCompleto, LocalDate fechNac, String contraseña, String email, String foto, int telefono, TipoUsuario tipo, LocalDateTime ultConexion, ArrayList<Tarjeta> tarjetas) {
        this.codigo = codigo;
        this.nombreCompleto = nombreCompleto;
        this.fechNac = fechNac;
        this.contraseña = contraseña;
        this.email = email;
        this.foto = foto;
        this.telefono = telefono;
        this.tipo = tipo;
        this.ultConexion = ultConexion;
        this.tarjetas = tarjetas;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public LocalDate getFechNac() {
        return fechNac;
    }

    public void setFechNac(LocalDate fechNac) {
        this.fechNac = fechNac;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }

    public LocalDateTime getUltConexion() {
        return ultConexion;
    }

    public void setUltConexion(LocalDateTime ultConexion) {
        this.ultConexion = ultConexion;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public TipoUsuario getTipo() {
        return tipo;
    }

    public void setTipo(TipoUsuario tipo) {
        this.tipo = tipo;
    }

    public ArrayList<Tarjeta> getTarjeta() {
        return tarjetas;
    }

    public void setTarjeta(ArrayList<Tarjeta> tarjeta) {
        this.tarjetas = tarjeta;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 97 * hash + this.codigo;
        hash = 97 * hash + Objects.hashCode(this.nombreCompleto);
        hash = 97 * hash + Objects.hashCode(this.fechNac);
        hash = 97 * hash + Objects.hashCode(this.foto);
        hash = 97 * hash + Objects.hashCode(this.ultConexion);
        hash = 97 * hash + this.telefono;
        hash = 97 * hash + Objects.hashCode(this.contraseña);
        hash = 97 * hash + Objects.hashCode(this.email);
        hash = 97 * hash + Objects.hashCode(this.tipo);
        hash = 97 * hash + Objects.hashCode(this.tarjetas);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Usuario other = (Usuario) obj;
        if (this.codigo != other.codigo) {
            return false;
        }
        if (this.telefono != other.telefono) {
            return false;
        }
        if (!Objects.equals(this.nombreCompleto, other.nombreCompleto)) {
            return false;
        }
        if (!Objects.equals(this.foto, other.foto)) {
            return false;
        }
        if (!Objects.equals(this.contraseña, other.contraseña)) {
            return false;
        }
        if (!Objects.equals(this.email, other.email)) {
            return false;
        }
        if (!Objects.equals(this.fechNac, other.fechNac)) {
            return false;
        }
        if (!Objects.equals(this.ultConexion, other.ultConexion)) {
            return false;
        }
        if (this.tipo != other.tipo) {
            return false;
        }
        return Objects.equals(this.tarjetas, other.tarjetas);
    }
    
    
    
}
