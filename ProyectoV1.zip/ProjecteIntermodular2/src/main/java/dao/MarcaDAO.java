/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import dto.Marca;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Optional;

/**
 *
 * @author ciclost
 */
public class MarcaDAO extends TablaDAO<Marca> {

    public MarcaDAO() {
        this.tabla = "MARCA";
    }

    @Override
    public int actualizar(Marca objeto) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int anyadir(Marca m) throws SQLException {
        String sentenciaSQL = "INSERT INTO " + tabla + " VALUES(?)";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setString(1, m.getNombre());
        return prepared.executeUpdate();
    }

    @Override
    public Marca eliminar(Marca m) throws SQLException {
        String sentenciaSQL = "DELETE FROM " + tabla + " WHERE nombre=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setString(1, m.getNombre());
        prepared.executeUpdate();
        return m;
    }

    @Override
    public boolean existe(Marca m) throws SQLException {
        return existe(m.getNombre());
    }

    public boolean existe(String marca) throws SQLException {
        return this.getNombreDe(marca).isPresent();
    }

    @Override
    public ArrayList<Marca> getAll() throws SQLException {
        ArrayList<Marca> listaMarcas = new ArrayList<>();
        String sentenciaSQL = "SELECT * FROM " + tabla + " ORDER BY nombre";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            String nombre = resultSet.getString("nombre");
            listaMarcas.add(new Marca(nombre));
        }

        return listaMarcas;
    }

    @Override
    public Marca getByCodigo(int codigo) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public Marca getByNombre(String nombre) throws SQLException {
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE nombre=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setString(1, nombre);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            String nom = resultSet.getString("nombre");
            return new Marca(nom);
        }

        return null;
    }
    

    public Optional<String> getNombreDe(String nombre) throws SQLException {
        String sentenciaSQL = "SELECT nombre FROM " + tabla + " WHERE nombre=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setString(1, nombre);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            return Optional.of(resultSet.getString("nombre"));
        }

        return Optional.empty();
    }

}
